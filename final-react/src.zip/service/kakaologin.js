export const REST_API_KEY = "9af54edd96e17a898bbe15f6a35bdf9d";
export const REDIRECT_URL = "http://localhost:3005/kakaologin";
export const KAKAO_AUTH_URL = `https://kauth.kakao.com/oauth/authorize?client_id=${REST_API_KEY}&redirect_uri=${REDIRECT_URL}&response_type=code`;
