import React from 'react';
import Footer from '../Common/Footer';
import Header from '../Common/Header';

const Statics = (props) => {
  return (
    <>
      <Header />
        <div className="body_container">
          <div>통계 관리 페이지</div>
        </div>
      <Footer />
    </>
  );
}

export default Statics;