import React from 'react';

const OrderResult = () => {
  return (
    <>
      <h2>결제완료 페이지</h2>
    </>
  );
};

export default OrderResult;